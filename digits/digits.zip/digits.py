import os
import numpy as np

train_X_temp = []

file_list = os.listdir('trainingDigits')
for train_file in file_list:
    with open('trainingDigits/'+train_file,'r') as train_x:
        train_X_temp.append(train_x.readlines())
        
#print(np.shape(train_X))
m = np.shape(train_X_temp)[0]

train_X = []

for i in train_X_temp:
    for j in i:
        train_X.append(j.strip('\n'))
        
np.reshape(train_X,(m,-1))
print(train_X)
print(m)
#with open()
#
#train_X = 